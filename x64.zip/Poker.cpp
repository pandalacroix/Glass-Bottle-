#include <iostream>
#include <string>
#include "PokerHand.h"


using namespace std;

int main()
{
	void displayRanking(string);

	string handStrings[] = { "ACKCQCJCTC", "6D5D9D8D7D", "2HKC2D2C2S", "6D5C6H5S6S", "3C6C9CQC2C",
							 "6H5C9S8D7D", "6D5C6H2S6S", "2D5C6H5S6S", "6D2C6HJSKS", "AD5C6HJS2S" };

	for (string hs : handStrings)
	{
		displayRanking(hs);
	}

	cout << endl << "Dealt from Deck:";
	PokerDeck deck;
	deck.shuffle();
	PokerHand hand(deck);
	hand.sortHand(true);
	cout << endl << hand.toString();
	cout << endl << hand.ranking() << endl;
}

void displayRanking(string hs)
{
	PokerHand hand(hs);
	hand.sortHand(true);
	cout << endl << hand.toString();
	cout << endl << hand.ranking() << endl;
}