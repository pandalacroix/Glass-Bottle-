#include "PlayingCard.h"    

    char charRank[] = { '2', '3', '4', '5', '6', '7', '8', '9', 'T', 'J', 'Q', 'K', 'A' };
    char charSuit[] = { 'C', 'D', 'H', 'S' };
    string stringRanks[] = { "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Jack", "Queen", "King", "Ace" };
    string stringSuits[] = { "Clubs", "Diamonds", "Hearts", "Spades" };

   
    char PlayingCard::getSuit() 
    {
        return suit;
    }

    void PlayingCard::setSuit(char p_suit) 
    {
        suit = p_suit;
    }

    char PlayingCard::getRank() 
    {
        return rank;
    }

    void PlayingCard::setRank(char p_rank) 
    {
        
        rank = p_rank;
    }

    PlayingCard::PlayingCard() 
    {
        rank = -1;
        suit = -1;
    }

    PlayingCard::PlayingCard(char p_rank, char p_suit) 
    {
        rank = p_rank;
        suit = p_suit;
    }

    PlayingCard::PlayingCard(string card) 
    {
        if (card.length() < 2)
        {
            rank = -1;
            suit = -1;

        }
        else
        {
            rank = findIndex(charRank, card[0]);
            suit = findIndex(charSuit, card[1]);
        }
        
    }

    int PlayingCard::findIndex(char charArray[], char charToFind)
    {
        for (int i = 0; i < 13; i++)
        {
            if (charArray[i] == charToFind)
            {
                
                return i;
            }
        }

        return -1;
    }

    string PlayingCard::toString()
    {
        string cardString = "";
        string rankString = "";
        string suitString = "";



        if (rank >= 0 && rank <= 13 && suit <= 3 )
        {

            cardString += string(1,charRank[rank]) + string(1, charSuit[suit]);
            return cardString;
        }
        else
        {
            return "Error";
        }
        
    }

    string PlayingCard::toStringLong() 
    {

        string cardString = "";
        string rankString = "";
        string suitString = "";

       
        if (rank >= 0 && rank <= 13 && suit <= 3)
        {
            cardString += stringRanks[rank] + stringSuits[suit];
            return cardString;
        }
        else
        {
            return "Error";
        }
        
    }

    string PlayingCard::rankToString() 
    {
        string cardString = "";

        if (rank >= 0 && rank <= 12)
        {
            cardString += charRank[rank];
            return cardString;
        }
        
        return "Error";
    }

    bool PlayingCard::isSameSuit(PlayingCard& pc) 
    {
        if (pc.getSuit() == suit) 
        {
            return true;
        }
        else 
        {
            return false;
        }
    }

    bool PlayingCard::isSameRank(PlayingCard& pc) 
    {
        if (pc.getRank() == rank) 
        {
            return true;
        }
        else 
        {
            return false;
        }
      
    }

    bool PlayingCard::isHigherRank(PlayingCard& pc) 
    {
        if (pc.getRank() < rank) 
        {
            return true;
        }
        else 
        {
            return false;
        }
    }

    bool PlayingCard::isLowerRank(PlayingCard& pc) 
    {
        if (pc.getRank() > rank) 
        {
            return true;
        }
        else 
        {
            return false;
        }
    }

    bool PlayingCard::isAdjacentRank(PlayingCard & pc) 
    {
        if (((rank == 1) && (pc.rank == 13)) || ((rank == 13) && (pc.rank == 1))) 
        {
            return true;  // Special case if Ace and King are adjacent
        }
        else if (abs(rank - pc.rank) == 1) 
        {
            return true;  
        }
        else 
        {
            return false;  
        }
    }
    
    bool PlayingCard::isAce() 
    {
        if (rank == findIndex(charRank, 'A')) 
        {
            return true;
        }
        else 
        {
            return false;
        }
    }
