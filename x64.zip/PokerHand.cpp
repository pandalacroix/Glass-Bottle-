
#include "PokerHand.h"
#include <string>

// Constructor for PokerHand
string stringRank[] = {"Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Jack", "Queen", "King", "Ace" };
string stringSuit[] = { "Clubs", "Diamonds", "Hearts", "Spades" };

PokerHand::PokerHand(string handString)
{
	
	if (handString.length() >= (5 * 2))
	{
		for (int i = 0; i < 5; i++)
		{
			hand[i] = new PlayingCard(string(1, handString[i * 2]) + string(1, handString[(i * 2) + 1]));
		}
	}
	else
	{
		for (int i = 0; i < 5; i++)
		{
			hand[i] = NULL;
		}
	}
}
PokerHand::PokerHand(PokerDeck deck)
{
	deck.shuffle();

	for (int i = 0; i < 5; i++)
	{
		hand[i] = deck.dealCard();

	}
}

void PokerHand::sortHand(bool)
{
	PlayingCard* cCard = NULL;
	PlayingCard* nCard = NULL;

	if ((hand[0] == NULL) || (hand[1] == NULL) || (hand[2] == NULL) || (hand[3] == NULL) || (hand[0] == NULL))
	{
		return;
	}

	for (int i = 0; i < 5 - 1;)
	{
		cCard = hand[i];
		nCard = hand[i + 1];

		//comparing each cards rank to that of the next card and swaps them, if a swap occurs then it restarts by looking at the first card again..
		if (cCard->isHigherRank(*nCard))
		{
			hand[i] = nCard;
			hand[i + 1] = cCard;
			i = 0;
		}
		else
		{
			i++;
		}
	}
	return;
}

string PokerHand::toString()
{
	string handString;

	//so you can see the screen with out word wrap around Mr. Richardson 
	if ((hand[0] == NULL) || 
		(hand[1] == NULL) || 
		(hand[2] == NULL) || 
		(hand[3] == NULL) || 
		(hand[0] == NULL))
	{
		return "Invalid Hand";
	}
	for (int i = 0; i < 5; i++)
	{
		handString += (hand[i]->toString()+ " ");
	}
	return handString;
}

string PokerHand::ranking()
{
	int hRank = -1;
	int lRank = -1;

	if ((hand[0] == NULL) ||
	    (hand[1] == NULL) ||
	    (hand[2] == NULL) ||
	    (hand[3] == NULL) ||
	    (hand[4] == NULL))
	{
		return "Invalid Hand";
	}
	else if (this->isRoyalFlush())
	{
		return "Royal Flush";
	}
	else if (this->isStraightFlush(hRank))
	{
		return "Straight Flush - " + stringRank[hRank] + " High";
	}
	else if (this->isFourOfAKind(hRank))
	{
		return "Four of a Kind - " + stringRank[hRank] + "s";
	}
	else if (this->isFullHouse(hRank, lRank))
	{
		return "Full House - " + stringRank[hRank] + "s full of " + stringRank[lRank] + "s";
	}
	else if (this->isFlush(hRank))
	{
		return "Flush - " + stringRank[hRank] + " High";
	}
	else if (this->isStraight(hRank))
	{
		return "Straight - " + stringRank[hRank] + " High";
	}
	else if (this->isThreeOfAKind(hRank))
	{
		return "Three of a Kind - " + stringRank[hRank] + "s";
	}
	else if (this->isTwoPair(hRank, lRank))
	{
		return "Two Pair - " + stringRank[hRank] + "s and " + stringRank[lRank] + "s";
	}
	else if (this->isPair(hRank, lRank))
	{
		return "One Pair - " + stringRank[hRank] + "s";
	}
	else
	{
		return stringRank[hand[4]->getRank()] + " High";
	}
}

bool PokerHand::isRoyalFlush()
{
	int hRank = -1;

	if (this->isStraightFlush(hRank) && hand[4]->isAce())
	{
		return true;
	}
	else
	{
		return false;
	}
}

bool PokerHand::isStraightFlush(int& hRank)
{
	if (this->isFlush(hRank) && this->isStraight(hRank))
	{
		return true;
	}
	else
	{
		return false;
	}	

}
bool PokerHand::isFourOfAKind(int& hRank)
{
	// Loop through the hand to count cards with the same rank as 'card'
	for (int i = 0; i < 5; i++)
	{
		int count = 0;

		for (int j = 0; j < 5; j++)
		{
			if (hand[j]->getRank() == hand[i]->getRank())
			{
				count++;
				if (count == 4)
				{
					hRank = static_cast<int>(hand[i]->getRank());
					return true;
				}
			}
		}
	}

	return false;
}
bool PokerHand::isFullHouse(int& setRank, int& pairRank) 
{
	//find the rank of the three of a kind then the rank of the pair excluding the rank of the three of a kind
	if (isThreeOfAKind(setRank) && isPair(pairRank, setRank))
	{
		return true;
	}
	else
	{
		setRank = -1;
		pairRank = -1;
		return false;
	}
}
bool PokerHand::isFlush(int& hRank)
{
	for (int i = 1; i < 5; i++)
	{
		if (hand[i]->getSuit() != hand[0]->getSuit())
		{
			hRank = -1;
			return false;
		}
	}

	hRank = static_cast<int>(hand[4]->getRank());
	return true;
}
bool PokerHand::isStraight(int& hRank)
{
	// Evaluates for special case: Ace-2-3-4-5 (Ace-low aka. wheel) straight
	if  (hand[4]->isAce() && 
		 hand[0]->isSameRank(*(new PlayingCard("2C"))) && 
		 hand[1]->isSameRank(*(new PlayingCard("3C"))) && 
		 hand[2]->isSameRank(*(new PlayingCard("4C"))) && 
		 hand[3]->isSameRank(*(new PlayingCard("5C"))))
	{
		hRank = static_cast<int>(hand[3]->getRank());
		return true;
	}

	for (int i = 1; i < 5; i++)
	{
		if (!hand[i]->isAdjacentRank(*hand[i-1]))
		{
			hRank = -1;
			return false;
		}
	}

	hRank = static_cast<int>(hand[4]->getRank());
	return true;
}
bool PokerHand::isThreeOfAKind(int& hRank)
{
	for (int i = 0; i < 5; i++)
	{
		int count = 0;

		for (int j = 0; j < 5; j++)
		{
			if (hand[j]->getRank() == hand[i]->getRank())
			{
				
				count++;

				if (count == 3)
				{
					hRank = static_cast<int>(hand[i]->getRank());
					return true;
				}
			}
		}
	}

	return false;
}

bool PokerHand::isTwoPair(int& hRank, int& lRank)
{
	//using the high rank value to exclude said value from the second pair.
	if (isPair(hRank, lRank) && isPair(lRank, hRank))
	{
		return true;
	}
	else
	{
		hRank = -1;
		lRank = -1;
		return false;
	}

}

bool PokerHand::isPair(int& hRank, int& excludeRank)
{
	for (int i = 0; i < 5; i++)
	{
		int count = 0;

		for (int j = 0; j < 5; j++)
		{
			if ((hand[j]->getRank() != excludeRank) && (hand[j]->getRank() == hand[i]->getRank()))
			{
				count++;

				if (count == 2)
				{
					hRank = static_cast<int>(hand[i]->getRank());
					return true;
				}
			}
		}
	}

	return false;
}



