#ifndef POKERHAND_H
#define POKERHAND_H

#include "PlayingCard.h"
#include "PokerDeck.h"

using namespace std;


class PokerHand 
{
private:
    PlayingCard* hand[5];
    
    bool isRoyalFlush();
    bool isStraightFlush(int&);
    bool isFourOfAKind(int&);
    bool isFullHouse(int&, int&);
    bool isFlush(int&);
    bool isStraight(int&);
    bool isThreeOfAKind(int&);
    bool isTwoPair(int&, int&);
    bool isPair(int&, int&);

public:
    PokerHand(string);
    PokerHand(PokerDeck);
    void sortHand(bool);
    string toString();
    string ranking();
};

#endif