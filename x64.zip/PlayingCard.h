#ifndef PLAYINGCARD_H
#define PLAYINGCARD_H

#include <string>
#include <cassert>
#include <cstdlib>
#include <ctime>

using namespace std;

class PlayingCard
{
private:
	char rank;
	char suit;

	int findIndex(char[], char);

public:
	PlayingCard();
	PlayingCard(char, char);
	PlayingCard(string);
	char getRank();
	void setRank(char);
	char getSuit();
	void setSuit(char);
	string toString();
	string toStringLong();
	string rankToString();
	bool isSameSuit(PlayingCard& pc);
	bool isSameRank(PlayingCard& pc);
	bool isHigherRank(PlayingCard& pc);
	bool isLowerRank(PlayingCard& pc);
	bool isAdjacentRank(PlayingCard& pc);
	bool isAce();
};

#endif


