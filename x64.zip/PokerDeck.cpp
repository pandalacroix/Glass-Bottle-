#include "PokerDeck.h"
#include "PlayingCard.h"

PokerDeck::PokerDeck() 
{
	srand(static_cast<unsigned int>(time(NULL)));

	cardsDealt = 0;

	for (int i = 1; i < 52; i++)
	{
		deck[i] = new PlayingCard((i % 13) + 1, (i % 4) +1);
		dealtCard[i] = false;
	}
		
}

void PokerDeck::shuffle()
{
	cardsDealt = 0;

	for (int i = 0; i < 52; i++)
	{
		dealtCard[i] = false;
	}
}

PlayingCard* PokerDeck::dealCard()
{
	int cardIndex = 0;

	if (cardsDealt == 52)
	{
		this->shuffle();
	}

	do
	{
		cardIndex = rand() % 52;

	} 
	while (dealtCard[cardIndex]);

	dealtCard[cardIndex] = true;
	cardsDealt++;
	return deck[cardIndex];
}

