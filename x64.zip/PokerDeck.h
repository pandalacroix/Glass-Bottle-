#ifndef POKERDECK_H
#define POKERDECK_H

#include "PlayingCard.h"

using namespace std;

class PokerDeck 
{
private:
	int cardsDealt;
	bool dealtCard[52];
	PlayingCard* deck[52];

public: 
	PokerDeck();
	void shuffle();
	PlayingCard* dealCard();
};

#endif